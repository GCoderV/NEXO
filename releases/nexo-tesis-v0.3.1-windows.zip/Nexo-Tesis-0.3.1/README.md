# Nexo Tesis 0.3.1

Agente académico independiente de Nexo PC. Empieza con un **tema**, conserva cada proyecto por separado y desarrolla propuestas revisables. No instala un complemento en Word ni incluye un tema de investigación obligatorio.

## Cambios de esta versión

- **Copilot funciona según la confirmación del usuario con 0.3.0.** Se conserva exactamente su código de conexión: no se volvió a cambiar el lanzamiento ni la captura pasiva.
- **Word:** corregida la asignación inválida `TableOfContents.UseOutlineLevels`. Es un parámetro de `TablesOfContents.Add`, no una propiedad del objeto resultante. Para crear se mantiene ese parámetro; para actualizar se registran los estilos APA mediante `HeadingStyles`, conservando las entradas personalizadas y evitando duplicar estilos.
- **Solo actualizar índice:** atajo en Organizar / APA 7 cuando existe un único índice automático. Desmarca el formato completo y limpia las inserciones seleccionadas, pero aún muestra una vista previa y exige aprobación. Sirve para revisar/terminar la operación que falló en 0.3.0 sin repetir todo el conjunto.
- **Trabajar solo:** plan local de apartados, ejecución acotada de varias tareas, avances visibles y guardados después de cada apartado, cancelación y motivos de parada. No envía «continúa» indefinidamente.
- **Continuar:** después de la recogida inicial pide un apartado concreto. Se comprueba que el texto haya cambiado; una promesa vacía recibe como máximo una corrección antes de detenerse. El número de versiones o las marcas de tiempo no cuentan como avance.

## Iniciar o actualizar

1. Descomprime **toda** esta carpeta en una ubicación propia. Para actualizar, usa una carpeta nueva y cierra la versión anterior.
2. Ejecuta **INICIAR-TESIS.cmd** en Windows 10/11. Necesitas tu instalación existente de Python 3.11 o superior, con Tkinter y SQLite. El iniciador no instala paquetes, sustituye Python ni modifica Nexo PC.
3. Tus proyectos se conservan en `%USERPROFILE%\.nexo-tesis\`, fuera de esta carpeta. **No borres ese directorio para actualizar.** Respáldalo con Nexo cerrado.
4. Abre **Modelos y cuentas**. La primera migración conserva una copia de la configuración anterior en `config-v01-respaldo.json`; revisa las cuentas importadas. Las rutas migradas no se incorporan automáticamente a la rotación.

El cliente WebSocket necesario ya está incluido. No necesitas instalar el proxy de referencia, Node, REA, Playwright ni un servidor adicional. Word de escritorio es opcional para conversar; hace falta para las operaciones nativas sobre documentos.

## Configurar cuentas y modelos

### Cuentas

En **Modelos y cuentas → Cuentas**:

- Elige proveedor, escribe un nombre para identificar la cuenta y su API key. Guarda la cuenta. Aparecerá en Modelos y rutas con un modelo sugerido y seleccionado en el editor; pulsa **Guardar y usar** para adoptarlo como ruta inicial, o elige otro ID primero.
- Puedes registrar varias cuentas del mismo proveedor. Una cuenta se reutiliza en cuantos modelos de **ese proveedor** selecciones: no necesitas duplicar su clave por modelo.
- **Recordar** guarda el secreto con Windows DPAPI, vinculado al usuario/equipo actuales. Desmarcado significa que Nexo conserva la credencial solo durante esta ejecución. En otros sistemas no hay sustituto en texto plano.
- Deja la clave vacía al editar una cuenta para conservarla. Deshabilitar o eliminar una cuenta la excluye de las llamadas automáticas. Eliminarla deja sus rutas sin credencial.
- «Lista; no verificada» significa que existe una credencial legible, no que Microsoft u otro proveedor la haya aceptado. No se hace inferencia al guardar.

Proveedores: **Google mediante Gemini API —incluidos IDs Gemma—, Groq, OpenRouter, Requesty, NVIDIA, Microsoft 365 Copilot experimental y Ollama local**. No se trata de GitHub Copilot.

### Modelos y rutas

1. Selecciona proveedor y cuenta en **Modelos y rutas**.
2. Pulsa **Actualizar lista** para consultar su catálogo, o escribe un ID compatible. La consulta de catálogo es explícita; no genera contenido. Los modelos publicados no garantizan acceso con tu cuenta.
3. **Guardar ruta** vincula ese modelo a la cuenta. Puedes añadir el mismo modelo con otra cuenta y otros modelos con la misma cuenta. Guarda los nuevos sin borrar los anteriores.
4. **Guardar y usar** establece la ruta inicial. Cambiarla **no crea un proyecto ni borra la conversación**.
5. Marca **Incluir esta ruta en la rotación automática** solo en las rutas que quieras autorizar para ese uso. Las flechas ordenan rutas dentro de los grupos de prioridad.

Para **Ollama**, inicia tu servicio local, selecciona el proveedor y pulsa **Actualizar lista**. La lista procede de `/api/tags`: no descarga modelos. Usa una dirección de bucle local, por ejemplo `http://127.0.0.1:11434`. Ollama se selecciona **manualmente**, no participa en rotación y nunca pasa silenciosamente a un proveedor remoto. Se rechazan etiquetas que contengan `cloud`; verifica además que tu instalación de Ollama no delegue en la nube por otra configuración.

Gemma en Google usa instrucciones dentro del mensaje y validación JSON en Nexo; no se presupone que admita todos los parámetros de Gemini. Otros modelos pueden rechazar el formato solicitado: en ese caso queda una petición pendiente, no una respuesta inventada.

### Rotación, cuotas y coste

Con rotación activa, se intenta:

**cuenta/modelo inicial → otras cuentas seleccionadas del mismo modelo → otros modelos configurados del proveedor → otros proveedores configurados y autorizados.**

Solo participan rutas habilitadas, marcadas para rotación y con una credencial del proveedor correcto. Un modelo de catálogo sin ruta, o una cuenta vacía, eliminada, deshabilitada o cuyo secreto no se puede abrir, recibe **cero llamadas**. Las credenciales de solo sesión sí pueden participar. Una cuenta rechazada por autenticación se pausa hasta que la guardes/reconectes; los límites técnicos conservan un tiempo de espera.

Por defecto hay hasta **6 intentos de transporte por ciclo** y un presupuesto de **180 segundos**; se pueden ajustar en Rotación y privacidad. No son un límite al número de cuentas. Se respetan los tiempos de espera del proveedor y no se crea un bucle infinito. El tiempo de una búsqueda o de una autorización también puede consumir el presupuesto antes de la segunda fase.

La rotación puede consumir cuota o saldo de las rutas que marques. **No todos los modelos son gratuitos**, incluso cuando exista una modalidad gratuita del servicio. Nexo no crea cuentas, activa suscripciones, compra créditos ni recarga saldos. Las cuotas pueden estar compartidas entre modelos o cuentas; no se exige demostrar que sean independientes. Consulta los precios y condiciones actuales en cada proveedor. En modalidades gratuitas de Google, revisa también sus condiciones de uso de los datos.

Antes de enviar, Nexo pide autorización de los destinatarios para ese proyecto. La conserva sin preguntarla en cada paso; una cuenta o modelo nuevo necesita autorización. Se comparten decisiones, el mensaje y extractos pertinentes, no todo el documento Word. No incluyas datos identificables de estudiantes.

## Continuar y Reanudar no son lo mismo

- **Continuar** propone el siguiente paso académico: es una solicitud nueva.
- **Reanudar** retoma una solicitud pendiente tras un error, agotamiento, detención o reinicio. No vuelvas a escribir su texto. Conserva su mensaje original, procedencia y fase guardada.
- Las propuestas y búsquedas ya guardadas no se ejecutan de nuevo. Reanudar nunca vuelve a insertar texto ni comentarios en Word.
- Si cambiaste el contenido del proyecto, se pide confirmar el contexto actualizado. No se duplica tu mensaje ni se repiten búsquedas completadas.
- Una respuesta que no cumple el formato académico no se aplica ni dispara otra llamada de reparación. Puedes elegir otra ruta y pulsar Reanudar.
- Si se perdió la respuesta después de enviar, el servidor pudo haber trabajado y consumido cuota. Se detiene el cambio automático y se pide confirmación antes de reanudar. **No puede garantizarse facturación exactamente una vez.**
- Detener impide nuevos pasos. Una petición HTTP ya enviada puede tardar hasta su límite de espera en terminar. No devuelve cuotas, retira peticiones del servidor ni deshace Word.

## Microsoft 365 Copilot — experimental, no oficial

**El usuario confirmó que Copilot funciona desde Nexo con 0.3.0. Su conexión se conserva en esta versión.** El asistente no tiene acceso autenticado a esa cuenta ni ha comprobado todas las condiciones de expiración/renovación o políticas institucionales. Las pruebas locales de transporte no sustituyen esa verificación real.

El transporte de las solicitudes de Nexo es **WebSocket/SignalR directo**. No se escribe ni se lee el chat por automatización DOM. Tampoco se extraen contraseñas, cookies de otros perfiles, almacenes generales de credenciales ni refresh tokens de MSAL. No se solicita que pegues tokens, solicitudes PowerShell o archivos HAR.

### Conectar desde Nexo

1. En Cuentas, pulsa **Nueva cuenta**, elige **Copilot365** y asigna un nombre.
2. Mantén **Escritorio M365** como método inicial. Cierra primero Microsoft 365 Copilot.
3. Pulsa **Conectar escritorio M365** y lee la autorización. Nexo intentará abrir la aplicación instalada con diagnóstico de bucle local. Comprueba que el puerto observado esté enlazado solo a `127.0.0.1`/`::1`. No instala la aplicación ni fuerza el cierre de procesos.
4. Inicia sesión **tú mismo** en la ventana de Microsoft. Espera a que Nexo indique que la observación está preparada. La ventana no se recarga desde Nexo.
5. Copia la frase **NEXO CONEXION…** con el botón correspondiente y envíala **manualmente** en un chat nuevo de Microsoft, **sin adjuntos**. Es una prueba de conexión, no la conversación académica. La espera está limitada a tres minutos.
6. Nexo conserva únicamente la conexión que transporta esa frase y una plantilla depurada de su invocación. La frase, el texto anterior y sus adjuntos no se guardan en la plantilla. El token queda en memoria o DPAPI según tu elección.
7. Guarda la ruta **auto** y pulsa **Guardar y usar**. Envía una solicitud desde la conversación de Nexo. Solo una respuesta recibida y validada confirmará la inferencia independiente; observar la conexión por sí solo no la confirma.
8. Si el escritorio no abre un puerto compatible, cambia el método a **Acceso con Edge** y vuelve a conectar. Es una ventana de autenticación de Microsoft en un perfil separado, no un bot que maneja el chat. No se instala Edge automáticamente. El botón conserva su nombre aunque selecciones este método.

Las solicitudes académicas y sus respuestas se muestran en Nexo. Se crean identificadores remotos separados por operación/cuenta; la continuidad de tus investigaciones la conserva el proyecto local, no una supuesta memoria ilimitada del servidor de Microsoft.

**Renovación:** al caducar, Nexo puede observar una conexión que Microsoft renueve de forma natural en la misma ventana autorizada y con la misma identidad. No se fuerza una recarga. Si no aparece una conexión nueva, debes reconectar y enviar la frase en un chat NUEVO. No se garantiza renovación sin ventana, sin volver a iniciar sesión o bajo todas las políticas institucionales. Si falla, reconecta desde Cuentas. No se desactiva MFA, acceso condicional, certificados TLS ni políticas de Office.

**Cierra las ventanas de Copilot/Edge abiertas para esta conexión al terminar**, de modo que cierre su puerto de diagnóstico. Aunque sea local, otros programas de tu usuario podrían acceder a ese puerto mientras esté abierto. El perfil separado de Edge guarda su propio estado de inicio de sesión en `.nexo-tesis/copilot-login`; elegir «solo sesión» para la credencial de Nexo no borra las cookies que administra el navegador. Cierra sesión allí si no deseas conservarlas.

El usuario informó que su aplicación ofrece modos automático, rápido y profundo y muestra GPT-5.6. Esta versión sigue usando **el modo observado al conectar** bajo el ID local `auto`; no incorpora todavía un selector independiente de los tres modos ni traduce esos nombres a alias privados supuestos.

No se fija una licencia Premium, no se transforma una cuenta Starter en otra modalidad y no se anuncian nombres internos de modelos. **auto** conserva la selección observada en el cliente; no certifica el modelo físico que responde. Los parámetros `licenseType`, `isEdu`, `source` o las variantes observadas no demuestran licencias ni capacidades. Microsoft sigue comprobando sus permisos y puede cambiar o rechazar el protocolo.

Copilot podría utilizar información institucional conforme a sus capacidades y permisos. Si autorizas otras rutas para el proyecto, los extractos que queden incorporados en él podrían enviarse a esos otros proveedores. Revisa ese permiso antes de usarlo con material interno. Nexo no expone terminal, herramientas generales de PC ni operaciones de Word al servicio Copilot.

## Trabajo autónomo sin pulsar Continuar en cada paso

1. Aporta tu tema y los datos disponibles como siempre. Guarda cualquier edición manual antes de empezar.
2. En **Conversación**, elige el máximo de apartados (2, 4, **6 por defecto**, 8 o 12) y pulsa **Trabajar solo**.
3. Revisa el plan que propone crear o revisar apartados y aprueba el conjunto. Se utilizan únicamente las rutas ya configuradas y autorizadas. Puede consumir cuota/saldo; no crea cuentas ni activa pagos.
4. Cada tarea solicita un borrador concreto. Verás el estado de ejecución y el avance guardado, sin tener que escribir «continúa». Se trabajan primero apartados faltantes/desactualizados y luego, cuando corresponde, borradores del modelo pendientes de revisión. No hay un pulido infinito: el mismo apartado no se vuelve a procesar con los mismos datos y texto tras completar su tarea.
5. **Detener** impide nuevos pasos y conserva los ya guardados. Una llamada en curso puede tardar en terminar. No se reinicia una sesión al abrir Nexo. **Reanudar** retoma únicamente la solicitud pendiente con sus controles habituales; no reinicia automáticamente el resto del conjunto.

Límites: hasta dos respuestas lógicas del modelo por apartado, incluida una corrección por falta de avance o una segunda fase después de búsqueda; los intentos de transporte siguen sujetos a los límites de rutas configurados. Tras diez minutos no se inicia otro apartado; una tarea ya iniciada puede finalizar después. Errores, cambios de destinatario, respuestas inciertas y falta de progreso detienen la sesión con un aviso, no con un bucle oculto. No se garantiza que un modelo entregue un texto académico correcto por haber producido un cambio.

Se protegen los apartados **aprobados, editados por ti o ya insertados en Word**, también si una modificación de datos los marcó como desactualizados. Los borradores antiguos sin procedencia identificable se conservan por precaución. Una revisión automática recibe el texto previo completo y no puede sustituir silenciosamente un borrador largo por un resumen de menos del 65 % de su extensión. Las versiones anteriores siguen conservadas según los límites del proyecto.

Las tareas automáticas se registran como actividades del sistema, **no como declaraciones tuyas**. No pueden aportar nuevos hechos, confirmar datos ni inventar resultados; resultados/discusión/conclusiones necesitan datos o corpus aportados y confirmados en Memoria. Se pueden desarrollar propuestas provisionales sin detenerse ante cada pregunta no bloqueante. Para trabajos documentales no se imponen instrumentos de participantes ni planes de acción.

**Alcance:** el modo autónomo escribe en **Apartados de Nexo**, no directamente en Word. Las operaciones Word siguen requiriendo su vista previa y aprobación. Con Permitir búsqueda activado, cada consulta externa conserva su aprobación explícita; sin activarlo, la sesión puede avanzar sobre el material disponible y señalar fuentes pendientes.

### Si falló el índice en 0.3.0

El error pudo aparecer después de aplicar formato e incluso crear el campo del índice. **No repitas a ciegas toda la operación.** Conserva la copia afectada, revísala en Word y usa una copia anterior si necesitas deshacer cambios. Si el formato está como deseas y existe un único índice, abre **Organizar / APA 7 → Solo actualizar índice**, revisa que no haya inserciones ni formato completo seleccionados y aprueba esa vista previa. No hay deshacer automático ni borrado de revisiones para ocultar el fallo.

## Flujo académico y fuentes

Empieza con el tema o pega directamente un texto de varias líneas con tus datos en la conversación inicial. Un tema breve crea el proyecto sin consultar al modelo; un texto inicial de varias líneas crea un proyecto por delimitar y, previa autorización del proveedor, lo envía una sola vez para extraer los datos. Si contiene un tema explícito, puede adoptarse como título con evidencia literal; no se sustituye silenciosamente el tema de un proyecto ya establecido.

En un proyecto existente también puedes pegar todos los datos juntos. No necesitas ordenarlos por campos. El modelo debe extraer primero lo aportado y reunir en un solo bloque las preguntas iniciales pertinentes que falten. Una respuesta tuya puede contestar varias preguntas a la vez. Lo declarado como «no definido» o «no disponible» no autoriza inventar resultados. Indica nivel, institución, metodología y contexto cuando proceda; ninguno está impuesto. Puedes corregir los datos en **Memoria**, aplazar preguntas, cambiar de proyecto y conservar el historial tras reiniciar.

Cada respuesta propone hasta dos apartados. Hay hasta dos **fases de generación** por turno; la segunda se usa después de una búsqueda autorizada. Esas fases no equivalen al número de intentos de transporte de la rotación. El contexto se acota a 24 000 caracteres más las instrucciones y salida, no a un número exacto de tokens. La conversación completa permanece local; la pantalla muestra los últimos cien mensajes.

Los hechos extraídos requieren evidencia literal del mensaje o tema, pero eso no certifica que su interpretación sea correcta. Las correcciones marcan borradores dependientes para revisión. Resultados, discusión y conclusiones requieren datos/corpus registrados y tu confirmación de disponibilidad; no se inventan resultados para completar apartados. Aun con controles, revisa cifras, citas y afirmaciones del modelo.

**Permitir búsqueda** habilita que se proponga una consulta de Crossref. Antes de enviarla se muestra el texto exacto. Máximo una consulta de cinco resultados por turno. Crossref aporta metadatos y a veces resúmenes: **no demuestra lectura de artículos completos**. Puedes registrar fragmentos realmente consultados con localizador y estado. Se bloquean IDs de fuentes inexistentes; un DOI existente tampoco prueba que respalde una afirmación.

El perfil UCE incluido es opcional y procede de una guía aportada de tres páginas; no es un manual institucional completo ni vigente verificado. Puedes aportar reglas de otras instituciones. APA/CSL completo, validadores institucionales adicionales, análisis estadístico especializado, voz continua y ajuste de un modelo para Ollama siguen pendientes. No se garantiza superar detectores ni sustituir la revisión académica.

## Word de escritorio — operaciones nativas y acotadas

**La automatización COM real sigue sin verificarse en Windows. Haz la primera prueba sobre una COPIA local, guardada en Word como `.docx`, sin datos sensibles.** No se utiliza Python-DOCX ni se instala un complemento.

Puedes usar **Crear en Word** para abrir un documento nuevo vacío: confirma la acción y guárdalo tú desde Word como `.docx`, con el nombre y ubicación que decidas. No se crea un archivo silenciosamente ni se asigna una autoría desde Nexo. **Abrir DOCX** permite elegir y confirmar una copia existente; se deshabilitan temporalmente macros y actualización automática de vínculos durante la apertura, se restauran las opciones y no se omiten las protecciones de Office. Estos botones están implementados; la prueba COM real sigue pendiente.

1. Abre y guarda esa copia en Word. En Nexo → Word, pulsa **Buscar abiertos** y selecciona el documento exacto.
2. En Word, selecciona un párrafo del cuerpo principal o coloca el cursor. Vuelve a Nexo y pulsa **Confirmar y leer**. Leer no envía automáticamente el fragmento a un modelo.
3. **Revisar en chat** prepara, previa autorización, un mensaje sin enviar con hasta 4500 caracteres. El documento no se interpreta como instrucciones ni decisiones del usuario.
4. Desde Apartados, **Preparar en Word** solo prepara texto. Revisa y aprueba **Insertar con revisiones** o **Añadir comentario** para modificar Word.
5. Comprueba el efecto en la copia. La inserción añade texto, no reemplaza lo anterior. Acepta/rechaza revisiones desde Word o elimina el comentario. Guarda tú el documento cuando corresponda.

Se comprueban documento, ventana, posición y huella del texto. No edites Word durante la operación. Cada autorización de selección se consume una vez; moverla exige volver a leer. Nexo no llama a Guardar/Guardar como, no cambia propiedades de autor ni acepta revisiones anteriores. **AutoSave de Word puede actuar por su cuenta.** Las operaciones usan marcadores o etiquetas `[Nexo:…]` para identificación.

Límites: DOCX guardado, editable y sin protección; cuerpo principal, no tablas, encabezados, notas ni selecciones múltiples. Lectura de hasta 12 000 caracteres, inserción de 10 000 y comentario de 6000. Puede detectar solo una instancia de Word. Se requiere el mismo usuario/nivel de permisos. El análisis de documento completo admite hasta 4000 párrafos y 2 millones de caracteres; cada apartado hasta 10 000 unidades UTF-16 y el lote hasta 60 000. No es un corrector bibliográfico integral ni certifica cumplimiento institucional. No eleves privilegios ni desactives políticas para sortear errores.

Un tiempo de espera puede dejar un efecto parcial: **inspecciona Word antes de repetir**. No hay reintentos automáticos de escritura ni deshacer general. Conserva copias de seguridad.

### Organización automática, índice y APA 7

1. Trabaja en una **copia local DOCX guardada**, abierta y activa en Word. Selecciónala en Nexo. No necesitas colocar el cursor para este flujo.
2. Pulsa **Organizar / APA 7** y autoriza el análisis local. Se lee el cuerpo para calcular huellas y reconocer párrafos, títulos y campos. Este análisis **no llama a un modelo ni le envía el documento**.
3. Deja activadas las opciones de formato del documento completo e índice, o desmarca lo que no quieras. Selecciona opcionalmente varios borradores guardados de Apartados. El texto editado solo en el cuadro de propuesta manual no se usa aquí.
4. Pulsa **Preparar vista previa**. Verás los títulos detectados, el texto nuevo, sus ubicaciones y las reglas de formato. Se inserta al final del apartado correspondiente; si falta, se propone crearlo en orden académico. **No reemplaza párrafos existentes ni decide correcciones semánticas dentro de ellos.** Los títulos duplicados/ambiguos, estructura no reconocible y varios índices bloquean las operaciones afectadas: corrígelos en Word o usa el flujo manual.
5. **Aprobar y aplicar conjunto** requiere confirmar esa vista previa. Si cambian el texto/estructura de Word o los borradores del proyecto, debe prepararse de nuevo. Las operaciones se ejecutan una vez, sin reintentos. Las inserciones se verifican y marcan para evitar repetir el mismo borrador.
6. Revisa la copia en Word. Las inserciones y el formato utilizan control de cambios, pero la paginación, campos y estilos no son una transacción reversible garantizada. No se aceptan revisiones automáticamente ni se llama a Guardar. AutoSave de Word puede guardar por su cuenta. Tras aceptar/rechazar revisiones, vuelve a actualizar **toda la tabla** desde Word si cambian las páginas.

**Base APA aplicada:** Times New Roman 12, doble espacio, párrafos del cuerpo alineados a la izquierda, 0 puntos antes/después, primera línea a 1,27 cm, márgenes de 2,54 cm, papel Carta. Encabezados de niveles 1–3, resumen sin sangría inicial, referencias con sangría francesa y citas en bloque explícitas con sangría. Conserva el texto y las negritas/cursivas existentes; no reescribe títulos ni elimina párrafos vacíos. La portada mantiene alineación/sangrías y requiere revisión de datos/disposición. El papel y los márgenes pueden redistribuir páginas.

**Índice real de Word:** creación antes del cuerpo reconocido o actualización del único índice existente, con niveles 1–3, enlaces y páginas calculadas por Word, no inventadas por un modelo. Se conservan entradas personalizadas de un índice previo; revísalas. Si no hay numeración ni contenido en encabezados/pies, se añade numeración superior derecha desde 1; si los hay, se preservan y se avisa para revisión. Se respetan tablas, figuras incrustadas, ecuaciones y contenido de cabeceras; notas, listas complejas, títulos 4–9, citas de varios párrafos y maquetación especial necesitan revisión humana.

**No es una certificación APA 7:** no inventa autores, años, DOI ni fuentes, ni convierte automáticamente `[F1]` en una cita válida. Tampoco corrige por sí solo todos los tipos de referencia, la correspondencia cita–referencia o requisitos propios de UASD/UCE. El índice general es una función solicitada para la tesis, no una exigencia universal de APA. Reglas de formato de referencia: [APA: párrafos](https://apastyle.apa.org/style-grammar-guidelines/paper-format/paragraph-format). Operaciones nativas: [Word TablesOfContents.Add](https://learn.microsoft.com/en-us/office/vba/api/word.tablesofcontents.add).

Si una operación falla o agota el tiempo, puede haber dejado un efecto parcial. **No la repitas a ciegas**: inspecciona la copia; revierte desde Word o vuelve a una copia previa según corresponda.

## Datos, recuperación y comprobaciones de esta versión

En `%USERPROFILE%\.nexo-tesis\`:

- `projects.sqlite3`: proyectos, historial y fases pendientes; seis checkpoints recientes y cinco versiones anteriores por apartado. Hasta 3 MB por proyecto.
- `config.json`: cuentas, rutas, catálogo y secretos DPAPI cuando se pidió recordarlos.
- `word-audit\`: intención/resultado y huellas de operaciones, sin texto del documento ni credenciales.
- `copilot-login\`: perfil de Edge separado, solo si utilizaste ese método.

Los proyectos y las exportaciones son **texto legible, no cifrado**. Respáldalos con Nexo cerrado. DPAPI no hace portable una clave a cualquier equipo o usuario. Si una configuración está dañada no se sobrescribe silenciosamente: conserva una copia antes de repararla o renombrarla. No borres el directorio de datos de Nexo PC.

Validación realizada en el entorno del asistente: **231 pruebas unitarias: 229 aprobadas y 2 omitidas por requerir Windows; 84 comprobaciones funcionales de interfaz Tk más 2 capturas opcionales**. Se ejecutó el cargador y el parser de PowerShell 7.4.6 en Linux: ocho comprobaciones de texto/rangos/estructura con dobles y cinco comprobaciones del contrato del índice con un objeto que rechaza explícitamente la propiedad inválida. También se probaron límites, cancelación, avance verificable, protección de borradores, contexto completo de revisión, no reactivación al abrir y ausencia de operaciones Word en el planificador. El código Copilot coincide byte a byte con el de 0.3.0.

**El usuario confirmó Copilot y la integración Word anterior; también aportó el error real de índice de 0.3.0. El asistente no ejecutó Word COM en Windows ni inferencia autenticada.** La corrección del índice aún necesita comprobarse en una copia en Word real. Las pruebas con dobles no certifican la maquetación final ni la calidad académica del modelo.

Esta descarga contiene únicamente el programa, su perfil opcional, este README y las licencias necesarias. Las pruebas, capturas, informes y scripts de desarrollo no forman parte del paquete.

### Licencias y referencias

Código Nexo: MIT; se conserva el aviso de autoría original en `LICENSE`. Cliente incluido `websocket-client` 1.9.2: Apache-2.0, aviso en `websocket/LICENSE` y cabeceras de sus módulos.

El adaptador Microsoft es una implementación propia limitada, estudiada mediante inventario REA, inspección de Python y pruebas de protocolo. Referencias estáticas: [Theprosonce/m365-copilot-proxy](https://github.com/Theprosonce/m365-copilot-proxy), commit `8eddc3e7bf772eb350da3d2bedc2656f79230b2c`, y [nqthiep/ms-copilot-api](https://github.com/nqthiep/ms-copilot-api), commit `334df528a58478b0f3fc4e74df8bcbb0bbd1e990`. No se ejecutaron ni distribuyen esos puentes. REA registró un inventario histórico parcial, no una prueba semántica de Python ni una verificación de Microsoft. No se ha clonado el servidor, los modelos o el producto Copilot completo.

Referencia del contrato corregido: [TableOfContents — propiedades documentadas](https://learn.microsoft.com/en-us/office/vba/api/word.tableofcontents) y [HeadingStyles.Add](https://learn.microsoft.com/en-us/office/vba/api/word.headingstyles.add).
