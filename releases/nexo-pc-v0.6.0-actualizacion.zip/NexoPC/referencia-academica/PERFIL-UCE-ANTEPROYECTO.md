# Perfil de trabajo: anteproyecto UCE — Educación — grado

## Fuente y alcance

Documento aportado por el usuario: `uploads/ESTRUCTURA DEL ANTEPROYECTO SEGÚN GUÍA UCE.pdf`, 3 páginas, leído íntegramente. Es una estructura/resumen con ejemplos de enseñanza de inglés; no se ha cotejado con la guía institucional completa ni confirmado su vigencia o aprobación. Se adopta como referencia de trabajo aportada, no como certificación de reglas universales de UCE. Los ejemplos no son el tema ni los datos reales del usuario.

## Estructura transcrita por apartados

### Capítulo I: Aproximación a la Realidad de la Investigación (p. 1)
1. Descripción del contexto: local e institucional.
2. Constitución del equipo de investigación: integrantes.
3. Descripción de la problemática (Planteamiento del Problema).
4. Justificación.
5. Conceptualización del tema (Marco Teórico).
6. Hipótesis de acción.
7. Objetivos: general y específicos.

### Capítulo II: Metodología de Investigación (Diseño Metodológico) (p. 2)
1. Constitución del equipo de investigación: roles.
2. Modelo de investigación: investigación-acción pedagógica; enfoque cualitativo o mixto según el documento. No seleccionar un enfoque sin justificación.
3. Población.
4. Técnicas e instrumentos de recolección de información.
5. Criterios éticos implicados en la investigación.

No eliminar automáticamente la repetición del equipo entre capítulos: el documento distingue integrantes y roles. Las técnicas e instrumentos de inglés son ejemplos, no instrumentos validados ni requisitos para cualquier tema.

### Capítulo III: Ciclo de la Investigación-Acción (Fase de Planificación) (pp. 2–3)
1. Diagnóstico de la planificación.
2. Presentación de los resultados del diagnóstico.
3. Diseño del plan de acción.

El documento limita el anteproyecto a la planificación. Sitúa acción, observación y reflexión en el proyecto de campo posterior y menciona un mínimo de 12 semanas. Esta duración queda atribuida a la fuente aportada, pendiente de cotejo institucional; no se extrapola como regla universal.

**Campos del plan de acción según la fuente:**
- Propósito General.
- Objetivos Específicos del Plan de Acción.
- Actividades a Desarrollar.
- Duración o Tiempo de cada actividad.
- Resultados Esperados.
- Técnicas e Instrumentos para Control de la Acción.
- Comentarios.

Los resultados del diagnóstico son datos iniciales reales, distintos de los resultados esperados del plan. Si no existen datos, marcar pendiente y preparar instrumentos; nunca redactar resultados como si se hubieran obtenido.

### Complementos (p. 3)
- Referencias bibliográficas.
- Anexos: glosario, cronograma y presupuesto, modelos de instrumentos para diagnóstico y control.

## Presentación indicada en el PDF (p. 3)

| Elemento | Indicación literal o equivalente de la fuente | Tratamiento |
|---|---|---|
| Texto | Times New Roman 12 | Regla del perfil aportado, pendiente de cotejo institucional. |
| Interlineado | 1.5 | No sustituir automáticamente por interlineado APA general. |
| Separación | Doble espacio entre capítulos | Ambiguo: confirmar traducción a espaciado/separación en Word; no interpretar como dos párrafos vacíos ni salto de página sin confirmación. |
| Títulos | Tamaño 14, MAYÚSCULA NEGRITA | No se especifica alineación. |
| Subtítulos | Tamaño 14, Minúscula Negrita | Confirmar capitalización exacta; no convertir nombres propios a minúsculas. |
| Referencias | Orden alfabético por primer apellido, año entre paréntesis, título en cursiva/negrita | La indicación cursiva/negrita es ambigua y no constituye una regla APA universal; resolver antes de automatizar. |
| Antigüedad | Fuentes de 2006 en adelante | No descartar automáticamente obras anteriores: consultar tratamiento de fuentes clásicas y posibles excepciones, especialmente ante autores sugeridos por el propio PDF. |

No se especifican márgenes, tamaño de papel, paginación, portada, sangrías ni edición de APA. Permanecen pendientes, sin inventar valores institucionales.

## Salvaguardas del perfil

- No convertir los ejemplos de inglés, tercer grado, ansiedad oral, role-playing o autores sugeridos en hechos del proyecto del usuario.
- Una hipótesis de acción expresa una expectativa, no demuestra eficacia causal ni resultados.
- Fuentes citadas y datos bibliográficos deben verificarse individualmente; mencionar autores en el PDF no proporciona referencias completas ni evidencia consultada.
- Mantener control de cambios, selección explícita del documento y privacidad del plan principal.
- No se ha creado ni editado ningún documento de Word con este perfil.

## Información pendiente para el primer caso

Tema real, carrera/mención cuando proceda, contexto educativo anonimizado, existencia de propuesta/documento y estado del diagnóstico. La guía oficial completa o aclaraciones del asesor permitirán resolver las reglas pendientes sin bloquear la planificación inicial.
