# Nexo Académico — expediente de trabajo



**Borrador local; no es una tesis terminada ni un documento oficial de UCE.**



Implementación de una estrategia de aprendizaje cooperativo basada en juegos de roles para fortalecer la producción oral en inglés de los estudiantes de 3.º de secundaria del Centro Educativo Divino Maestro (2026–2027).



UCE — Universidad Central del Este · Grado · Educación · Investigación-acción

Período: 2026–2027 · Diagnóstico: 24 participantes · escrita y oral



## Diagnóstico aportado

Informe narrativo aportado por el docente: conocimientos elementales de vocabulario, expresiones frecuentes y estructuras básicas. Las respuestas de autopercepción indican dificultades con la pronunciación, lectura, gramática y vocabulario; práctica fuera del aula poco frecuente e inseguridad al hablar. No se aportaron frecuencias ni puntuaciones.



### Tareas orales

Presentación personal básica; entrevista a compañeros; presentación del compañero entrevistado.



### Observaciones

Pocas dificultades de vocabulario al presentarse; mayor dificultad al formular preguntas; algunas dificultades para expresar el género del compañero presentado. El docente aclara que el dominio es muy bajo para 3.º de secundaria y que el miedo a hablar es la dificultad principal. Conocer expresiones elementales no implica dominio adecuado al grado. No se conocen errores lingüísticos concretos ni se ha cotejado el currículo.



## Propuestas por revisar

### Pregunta

¿Cómo contribuye una estrategia de aprendizaje cooperativo basada en juegos de roles al fortalecimiento de la producción oral en inglés del grupo durante 2026–2027?

### Objetivo general

Fortalecer la producción oral en inglés mediante una estrategia de aprendizaje cooperativo basada en juegos de roles, atendiendo los recursos lingüísticos y la seguridad para participar.

### Objetivos específicos

1. Diagnosticar el desempeño oral y la seguridad percibida al hablar inglés, distinguiendo observación y autopercepción.

2. Diseñar la estrategia a partir de las necesidades del diagnóstico.

3. Implementar la estrategia con apoyos lingüísticos y participación progresiva, documentando su desarrollo.

4. Analizar los cambios observados en la producción oral y la seguridad percibida, y reflexionar para ajustar la práctica.

### Hipótesis de acción — expectativa, no resultado

Si se implementan juegos de roles cooperativos con preparación lingüística, ensayo y apoyo respetuoso entre compañeros, se espera favorecer la seguridad para participar y el desarrollo de la producción oral. Es una expectativa por evaluar, no una eficacia demostrada.



## Evidencias

- **E1 · autopercepción**: Miedo e inseguridad al hablar — El informe recoge nerviosismo, vergüenza y preferencia por no participar en algunos casos; el docente identifica el miedo como dificultad central. (Sin frecuencia aportada).

- **E2 · observación docente**: Dominio limitado para el grado — Valoración del docente; contraste curricular pendiente. (Sin frecuencia aportada).

- **E3 · observación docente**: Mayor dificultad al formular preguntas — Observada durante entrevistas entre compañeros; sin rúbrica ni frecuencias aportadas. (Sin frecuencia aportada).

- **E4 · observación docente**: Dificultades al presentar a otra persona — Algunas dificultades al expresar el género; no se especificaron formas lingüísticas concretas. (Sin frecuencia aportada).



## Plan de acción propuesto — no ejecutado por Nexo

### Actividad 1 · planificada

**Propósito general:** Fortalecer la producción oral y favorecer la seguridad para participar.

**Objetivo específico:** Preparar recursos lingüísticos para el intercambio oral.

**Actividad:** Modelado de un diálogo breve y preparación cooperativa de vocabulario y preguntas; cada integrante aporta y ensaya una parte.

**Duración:** Pendiente

**Resultados esperados:** Se espera que cada estudiante disponga de expresiones útiles para iniciar el intercambio.

**Técnicas e instrumentos:** Lista de cotejo de recursos lingüísticos y diario docente; instrumentos por revisar.

**Comentarios:** Propuesta pendiente de revisión. No se ha ejecutado. Distribución temporal y autorizaciones por confirmar.

**Evidencias vinculadas:** E2, E3

### Actividad 2 · planificada

**Propósito general:** Fortalecer la producción oral y favorecer la seguridad para participar.

**Objetivo específico:** Facilitar participación progresiva en un ambiente de apoyo.

**Actividad:** Ensayo de juegos de roles en parejas, con tarjetas de apoyo, turnos equitativos y retroalimentación respetuosa. Sin exposición pública forzada al inicio.

**Duración:** Pendiente

**Resultados esperados:** Se espera ampliar las oportunidades de hablar y favorecer la seguridad percibida.

**Técnicas e instrumentos:** Registro de participación y breve autopercepción; no equivale a escala clínica ni instrumento validado.

**Comentarios:** Propuesta pendiente de revisión. No se ha ejecutado. Distribución temporal y autorizaciones por confirmar.

**Evidencias vinculadas:** E1, E2

### Actividad 3 · planificada

**Propósito general:** Fortalecer la producción oral y favorecer la seguridad para participar.

**Objetivo específico:** Practicar preguntas y comunicación de información sobre otras personas.

**Actividad:** Juego de roles de entrevista con una meta compartida; rotación de roles de entrevistador y entrevistado y presentación del personaje. Reducir apoyos según desempeño.

**Duración:** Pendiente

**Resultados esperados:** Se espera que los estudiantes formulen preguntas y comuniquen información con apoyos gradualmente menores.

**Técnicas e instrumentos:** Rúbrica oral por revisar y registro de ayudas utilizadas.

**Comentarios:** Propuesta pendiente de revisión. No se ha ejecutado. Distribución temporal y autorizaciones por confirmar.

**Evidencias vinculadas:** E3, E4

### Actividad 4 · planificada

**Propósito general:** Fortalecer la producción oral y favorecer la seguridad para participar.

**Objetivo específico:** Reflexionar sobre el desempeño y ajustar el siguiente ciclo.

**Actividad:** Tarea oral comparable con la inicial; reflexión individual y del equipo sobre comunicación y seguridad. Decidir ajustes con las evidencias recogidas.

**Duración:** Pendiente

**Resultados esperados:** Se espera identificar avances, dificultades persistentes y ajustes; no se anticipan mejoras medidas.

**Técnicas e instrumentos:** Criterios comparables al diagnóstico, autopercepción y diario de campo; límites de comparación por documentar.

**Comentarios:** Propuesta pendiente de revisión. No se ha ejecutado. Distribución temporal y autorizaciones por confirmar.

**Evidencias vinculadas:** E1, E2, E3, E4



## Registro de fuentes — no es bibliografía APA validada



## Comprobaciones y pendientes

- [advertencia] Perfil basado en el PDF aportado; falta cotejo con la guía completa. Márgenes, portada y reglas bibliográficas ambiguas siguen pendientes.

- [advertencia] El dominio bajo para el grado es una valoración docente; falta contraste documentado con el currículo. No asignar nivel MCER.

- [advertencia] Dominio limitado y miedo a hablar coexisten; no se ha demostrado que uno cause el otro ni que la estrategia sea eficaz.

- [pendiente] Hay evidencia narrativa sin frecuencias. No convertir «mayoría» o «algunos» en porcentajes.

- [pendiente] Actividad 1: falta Duración.

- [pendiente] Actividad 2: falta Duración.

- [pendiente] Actividad 3: falta Duración.

- [pendiente] Actividad 4: falta Duración.

- [pendiente] Sin fuentes bibliográficas registradas. No generar citas ficticias.

- [advertencia] Confirmar autorizaciones y protección de datos antes de nuevas recogidas o grabaciones. No registrar nombres de estudiantes.
