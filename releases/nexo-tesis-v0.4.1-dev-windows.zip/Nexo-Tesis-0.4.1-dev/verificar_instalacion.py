"""Offline self-check for the packaged Windows app. No network, no credentials.

Verifies the internal SHA256SUMS.txt, that every runtime module imports, and that
Python/Tk/SQLite are usable. Called by INICIAR-TESIS.cmd and VERIFICAR.cmd.
"""
import hashlib
import importlib
import sys
from pathlib import Path
from version import VERSION, BUILD

ROOT = Path(__file__).resolve().parent
CORE = ('agent', 'autonomy', 'bibliography', 'config', 'context_policy',
        'conversation_state', 'copilot_metadata', 'copilot_socket', 'guide_rules',
        'materials', 'native_material', 'project_store', 'prompt_policy', 'providers',
        'routing', 'secrets_store', 'word_bridge', 'word_layout', 'pypdf', 'websocket')
UI = ('app', 'material_dialog', 'settings_dialog', 'word_layout_dialog')


def check_data_dir():
    """Preflight the user data folder WITHOUT reading keys or projects.

    A read-only ~/.nexo-tesis makes every save fail at runtime with an opaque
    error; detecting it here gives an actionable message before the app opens.
    """
    import os
    path = Path.home() / '.nexo-tesis'
    label = '~/.nexo-tesis'
    if not path.exists():
        print('Datos: ' + label + ' se creara al abrir Nexo (no se crea ahora).')
        return []
    if not os.access(path, os.W_OK):
        return ['Sin permiso de escritura en ' + label + ': Nexo no podra guardar proyectos ni configuracion. Revisa los permisos de tu carpeta de usuario.']
    print('Datos: carpeta accesible; no se leyeron claves ni proyectos.')
    return []


def check_long_draft():
    """Functional proof that THIS copy accepts the user's long task reply.

    The recurring "La respuesta no cumple el formato académico" was caused by a
    10000-character cap in an older build. Running this at startup tells the user
    immediately whether they opened the corrected ZIP or a stale folder.
    """
    import json
    from limits import MAX_DRAFT_CHARS
    from agent import unpack
    text = ('### Marco teórico\n\n'
            + 'Párrafo de prueba con acentos, 3.º de secundaria y\n\n'
            * 260)
    raw = json.dumps({'text': text, 'sources': [],
                      'reply': 'Borrador de prueba, sin fuentes.'}, ensure_ascii=False)
    assert len(json.loads(raw)['text']) > 10000
    result = unpack(raw, {'section': 'marco_teorico'})
    drafts = result.get('drafts', [])
    if (len(drafts) != 1 or drafts[0]['section'] != 'marco_teorico'
            or len(drafts[0]['text']) <= 10000):
        return ['Esta copia sigue rechazando borradores largos: descarga el ZIP nuevo y descomprímelo en una carpeta vacía.']
    return []


def main():
    problems = []
    print(f'Nexo Tesis {VERSION} ({BUILD}) - comprobacion local (sin red)')
    print('Python:', sys.version.split()[0])
    if sys.version_info < (3, 11):
        problems.append('Se requiere Python 3.11 o superior.')

    manifest = ROOT / 'SHA256SUMS.txt'
    count = 0
    if not manifest.is_file():
        problems.append('Falta SHA256SUMS.txt; el paquete podria estar incompleto.')
    else:
        for line in manifest.read_text('utf-8').splitlines():
            if '  ' not in line:
                continue
            expected, name = line.split('  ', 1)
            path = (ROOT / name).resolve()
            if (not path.is_relative_to(ROOT) or not path.is_file()
                    or hashlib.sha256(path.read_bytes()).hexdigest() != expected):
                problems.append('Archivo alterado o ausente: ' + name)
            count += 1
    print('Archivos comprobados:', count)

    for name in CORE:
        try:
            importlib.import_module(name)
        except Exception as e:
            problems.append('No se pudo importar ' + name + ': ' + type(e).__name__ + ' ' + str(e)[:100])
    print('Modulos basicos:', len(CORE))

    try:
        import tkinter
        print('Tkinter: disponible (Tk ' + str(tkinter.TkVersion) + ')')
    except Exception as e:
        problems.append('Falta Tkinter / Tcl-Tk: ' + str(e)[:100])
    else:
        for name in UI:
            try:
                importlib.import_module(name)
            except Exception as e:
                problems.append('No se pudo importar ' + name + ': ' + type(e).__name__ + ' ' + str(e)[:100])
        print('Modulos de interfaz:', len(UI))

    try:
        import sqlite3
        print('SQLite:', sqlite3.sqlite_version)
    except Exception as e:
        problems.append('Falta SQLite: ' + str(e)[:100])

    problems += check_data_dir()
    try:
        draft_issues = check_long_draft()
    except Exception as e:
        problems.append('No se pudo comprobar el validador de borradores: ' + type(e).__name__ + ' ' + str(e)[:100])
    else:
        if draft_issues:
            problems += draft_issues
        else:
            from limits import MAX_DRAFT_CHARS
            print('Borradores largos: OK (hasta ' + str(MAX_DRAFT_CHARS) + ' caracteres).')
    if problems:
        print('')
        print('PROBLEMAS ENCONTRADOS:')
        for item in problems:
            print(' - ' + item)
        print('')
        print('No se iniciara la aplicacion. Revisa lo anterior; no se conecto a ningun servicio.')
        return 1
    print('')
    print('Todo correcto. No se leyeron claves ni se envio nada a Internet.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
