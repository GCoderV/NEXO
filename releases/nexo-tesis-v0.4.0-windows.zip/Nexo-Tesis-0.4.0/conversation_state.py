"""Opt-in project/account-scoped transport continuity; never assumes server recall."""
import copy,hashlib,json,re

def keys(api):
    out={}
    for r in getattr(api,'routes',[]):
        if r['provider']!='Copilot365':continue
        aid=r['account_id'];generation=api.config.data['accounts'].get(aid,{}).get('generation','')
        out[aid]=hashlib.sha256(json.dumps([aid,generation,r['endpoint']]).encode()).hexdigest()
    return out

def load(p,api):
    if not p.get('copilot_continuity'):return {}
    result={}
    for aid,key in keys(api).items():
        slot=p.get('copilot_threads',{}).get(key,{})
        if valid(slot) and slot['turns']<40:result[aid]=copy.deepcopy(slot)
    return result

def valid(slot):
    return isinstance(slot,dict) and all(isinstance(slot.get(k),str) and re.fullmatch(r'[a-fA-F0-9-]{32,36}',slot[k]) for k in ('conversation','session')) and type(slot.get('turns')) is int and 0<=slot['turns']<=40

def save(p,api,remote,uncertain=False):
    if not p.get('copilot_continuity'):return
    for aid,key in keys(api).items():
        if uncertain:p.setdefault('copilot_threads',{}).pop(key,None);continue
        slot=remote.get(aid,{})
        if valid(slot):p.setdefault('copilot_threads',{})[key]={k:slot[k] for k in ('conversation','session','turns')}
